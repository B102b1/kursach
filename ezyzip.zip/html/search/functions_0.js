var searchData=
[
  ['connect_5fto_5fserver_17',['Connect_to_server',['../classConnect.html#a347a54af857f70bc997a34b97397663b',1,'Connect']]]
];
