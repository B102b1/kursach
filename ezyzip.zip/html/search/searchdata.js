var indexSectionsWithContent =
{
  0: "cegm",
  1: "ce",
  2: "cm",
  3: "cgm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции"
};

